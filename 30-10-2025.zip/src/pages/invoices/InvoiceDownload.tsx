import React, { useRef, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { useStudentInvoice, useTeacherInvoice } from '@/hooks/useInvoiceDetails';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import jsPDF from 'jspdf';
import { toast } from 'sonner';

const formatDate = (dateString: string | null) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit' });
};

const formatCurrency = (amount: number) => {
  return `€${amount.toFixed(2)}`;
};

const InvoiceDownload = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type') as 'receivables' | 'payables' | null;
  const invoiceRef = useRef<HTMLDivElement>(null);

  const invoiceId = id ? parseInt(id) : null;

  const { data: studentInvoiceData, isLoading: studentLoading } = useStudentInvoice(
    type === 'receivables' ? invoiceId : null
  );
  const { data: teacherInvoiceData, isLoading: teacherLoading } = useTeacherInvoice(
    type === 'payables' ? invoiceId : null
  );

  const isLoading = type === 'receivables' ? studentLoading : teacherLoading;
  const invoiceData = type === 'receivables' ? studentInvoiceData : teacherInvoiceData;

  const handleDownloadPDF = async () => {
    if (!invoiceData) return;

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      let yPosition = 20;

      if (type === 'receivables' && studentInvoiceData) {
        const { invoice, details, contract } = studentInvoiceData;
        const student = invoice.tbl_students!;

        // Group details as in PHP
        const groupedDetails = details.reduce((acc: any, detail: any) => {
          const key = `${detail.fld_ssid || 'none'}-${detail.fld_detail}-${detail.fld_len_lesson}-${detail.fld_s_rate}-${detail.fld_my}`;
          if (!acc[key]) {
            acc[key] = {
              ...detail,
              fld_lesson: 0,
              total: 0,
            };
          }
          acc[key].fld_lesson += detail.fld_lesson || 0;
          acc[key].total += (detail.fld_lesson || 0) * (detail.fld_s_rate || 0);
          return acc;
        }, {});

        const groupedDetailsArray = Object.values(groupedDetails);

        // Header
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        doc.text('Rechnung', pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 10;

        // Company details
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.text('Tav und Uzun Gbr', 20, yPosition);
        yPosition += 5;
        doc.text('CleverCoach Nachhilfe', 20, yPosition);
        yPosition += 5;
        doc.text('Höschenhofweg 31', 20, yPosition);
        yPosition += 5;
        doc.text('47249 Duisburg', 20, yPosition);
        yPosition += 10;

        // Contact info
        doc.text('Telefon: 0203 39652097', pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text('E-Mail: kontakt@clevercoach-nachhilfe.de', pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text('Internet: www.clevercoach-nachhilfe.de', pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 15;

        // Student details
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text('Rechnungsempfänger:', 20, yPosition);
        yPosition += 10;

        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.text(`${student.fld_first_name} ${student.fld_last_name}`, 20, yPosition);
        yPosition += 5;
        doc.text(student.fld_address || '', 20, yPosition);
        yPosition += 5;
        doc.text(`${student.fld_zip}, ${student.fld_city}`, 20, yPosition);
        yPosition += 10;

        // Invoice details
        doc.text(`Rechnungsdatum: ${formatDate(invoice.fld_edate)}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text(`Rechnungsnummer: ${invoice.fld_id}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text(`Kundennummer: ${student.fld_id}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 15;

        // Invoice table
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        
        // Table headers
        const tableHeaders = ['Leistungszeitraum', 'Beschreibung', 'Menge', 'Dauer', 'Einzelpreis', 'Summe'];
        const colWidths = [30, 60, 20, 25, 25, 25];
        let xPosition = 20;

        tableHeaders.forEach((header, index) => {
          doc.text(header, xPosition, yPosition);
          xPosition += colWidths[index];
        });
        yPosition += 8;

        // Table rows
        doc.setFont('helvetica', 'normal');
        groupedDetailsArray.forEach((detail: any) => {
          if (yPosition > pageHeight - 30) {
            doc.addPage();
            yPosition = 20;
          }

          let finalLesson = Math.round(detail.fld_lesson);
          
          // Apply minimum lesson logic
          if (detail.fld_detail !== 'Anmeldegebühr') {
            if (invoice.fld_ch_hr === 'Y' && invoice.fld_min_lesson) {
              if (finalLesson < invoice.fld_min_lesson) {
                finalLesson = invoice.fld_min_lesson;
              }
            }
          }

          const rate = detail.fld_s_rate || 0;
          const lineTotal = detail.fld_detail === 'Anmeldegebühr'
            ? detail.total
            : Number((rate * finalLesson).toFixed(2));

          xPosition = 20;
          doc.text(detail.fld_my || '', xPosition, yPosition);
          xPosition += colWidths[0];
          doc.text(detail.fld_detail || '', xPosition, yPosition);
          xPosition += colWidths[1];
          doc.text(finalLesson.toString(), xPosition, yPosition);
          xPosition += colWidths[2];
          doc.text(detail.fld_len_lesson || '', xPosition, yPosition);
          xPosition += colWidths[3];
          doc.text(formatCurrency(rate), xPosition, yPosition);
          xPosition += colWidths[4];
          doc.text(formatCurrency(lineTotal), xPosition, yPosition);
          yPosition += 6;
        });

        // Total row
        yPosition += 5;
        doc.setFont('helvetica', 'bold');
        doc.text('Rechnungsbetrag:', pageWidth - 50, yPosition);
        doc.text(formatCurrency(invoice.fld_invoice_total || 0), pageWidth - 20, yPosition);
        yPosition += 10;

        // Tax note
        doc.setFontSize(8);
        doc.setFont('helvetica', 'italic');
        doc.text('Die erbrachten Bildungsleistungen sind gemäß § 4 Nr. 21 UStG von der Umsatzsteuer befreit.', 20, yPosition);
        yPosition += 15;

        // Payment information
        if (contract) {
          if (contract.fld_p_mode === 'Überweisung') {
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            doc.text('Bitte überweisen Sie den Rechnungsbetrag innerhalb von 14 Tagen auf das folgende Bankkonto:', 20, yPosition);
            yPosition += 8;
            doc.text('Name: Tav und Uzun Gbr', 20, yPosition);
            yPosition += 5;
            doc.text('Bankinstitut: Commerzbank', 20, yPosition);
            yPosition += 5;
            doc.text('IBAN: DE82350400380422117200', 20, yPosition);
            yPosition += 5;
            doc.text('BIC: COBADEFFXXX', 20, yPosition);
          } else if (contract.fld_p_mode === 'Lastschrift') {
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            doc.text('Der Betrag wird vereinbarungsgemäß per SEPA-Lastschrift von Ihrem hinterlegten Konto abgebucht:', 20, yPosition);
            yPosition += 8;
            doc.text(`Kontoinhaber/in: ${student.fld_payer || 'N/A'}`, 20, yPosition);
            yPosition += 5;
            doc.text(`Bankinstitut: ${contract.fld_bi || 'N/A'}`, 20, yPosition);
            yPosition += 5;
            doc.text(`IBAN: ${contract.fld_iban || 'N/A'}`, 20, yPosition);
            yPosition += 5;
            doc.text(`Mandatsreferenz: MANDE${student.fld_id}`, 20, yPosition);
          }
        }

        yPosition += 15;

        // Footer
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Mit freundlichen Grüßen,', 20, yPosition);
        yPosition += 5;
        doc.text('Ihr CleverCoach-Team', 20, yPosition);
        yPosition += 10;

        doc.setFontSize(8);
        doc.text('Diese Abrechnung wurde mittels EDV erstellt und ist auch ohne Unterschrift gültig.', pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 8;

        doc.text('CleverCoach Nachhilfe – Tav und Uzun GbR – Höschenhofweg 31, 47249 Duisburg', pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 4;
        doc.text('Bankverbindung: Commerzbank, IBAN: DE82350400380422117200 BIC: COBADEFFXXX', pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 4;
        doc.text('Steuernummer: 5109 / 5709 / 1834  Finanzamt Duisburg', pageWidth / 2, yPosition, { align: 'center' });

        // Save PDF
        const fileName = `Invoice_${student.fld_last_name}_${student.fld_first_name}_${invoice.fld_id}.pdf`;
        doc.save(fileName);
        
        toast.success('PDF downloaded successfully');
      }

      if (type === 'payables' && teacherInvoiceData) {
        const { invoice, details } = teacherInvoiceData;
        const teacher = invoice.tbl_teachers!;

        // Group details as in PHP
        const groupedDetails = details.reduce((acc: any, detail: any) => {
          const key = `${detail.fld_ssid || 'none'}-${detail.fld_detail}-${detail.fld_len_lesson}-${detail.fld_t_rate}-${detail.fld_my}`;
          if (!acc[key]) {
            acc[key] = {
              ...detail,
              fld_lesson: 0,
              total: 0,
            };
          }
          acc[key].fld_lesson += detail.fld_lesson || 0;
          acc[key].total += (detail.fld_lesson || 0) * (detail.fld_t_rate || 0);
          return acc;
        }, {});

        const groupedDetailsArray = Object.values(groupedDetails);

        // Header
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        doc.text('Honorarabrechnung - Selbstgutschrift', pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 15;

        // Teacher details
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.text(`${teacher.fld_first_name} ${teacher.fld_last_name} - ${teacher.fld_street} - ${teacher.fld_zip} - ${teacher.fld_city} - ${teacher.fld_bakk_rno}`, 20, yPosition);
        yPosition += 10;

        // Company details
        doc.text('Tav und Uzun GbR', 20, yPosition);
        yPosition += 5;
        doc.text('CleverCoach Nachhilfe', 20, yPosition);
        yPosition += 5;
        doc.text('Höschenhofweg 31', 20, yPosition);
        yPosition += 5;
        doc.text('47249 Duisburg', 20, yPosition);
        yPosition += 10;

        // Invoice details
        doc.text(`Datum der Ausstellung: ${formatDate(invoice.fld_edate)}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text(`Lehrkraft-Nr.: ${teacher.fld_id}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 5;
        doc.text(`Rechnungsnummer: ${invoice.fld_id}`, pageWidth - 20, yPosition, { align: 'right' });
        yPosition += 10;

        doc.setFont('helvetica', 'bold');
        doc.text('Vielen Dank für das Vertrauen in meine Dienste. Anbei übersende ich Ihnen meine Honorarabrechnung für den letzten Monat.', 20, yPosition);
        yPosition += 15;

        // Invoice table
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        
        // Table headers
        const tableHeaders = ['Leistungszeitraum', 'Beschreibung', 'Menge', 'Dauer', 'Einzelpreis', 'Summe'];
        const colWidths = [30, 60, 20, 25, 25, 25];
        let xPosition = 20;

        tableHeaders.forEach((header, index) => {
          doc.text(header, xPosition, yPosition);
          xPosition += colWidths[index];
        });
        yPosition += 8;

        // Table rows
        doc.setFont('helvetica', 'normal');
        groupedDetailsArray.forEach((detail: any) => {
          if (yPosition > pageHeight - 30) {
            doc.addPage();
            yPosition = 20;
          }

          const lessonCount = Math.round(detail.fld_lesson);
          const rate = detail.fld_t_rate || 0;
          const lineTotal = detail.total;

          xPosition = 20;
          doc.text(detail.fld_my || '', xPosition, yPosition);
          xPosition += colWidths[0];
          doc.text(detail.fld_detail || '', xPosition, yPosition);
          xPosition += colWidths[1];
          doc.text(lessonCount.toString(), xPosition, yPosition);
          xPosition += colWidths[2];
          doc.text(detail.fld_len_lesson || '', xPosition, yPosition);
          xPosition += colWidths[3];
          doc.text(formatCurrency(rate), xPosition, yPosition);
          xPosition += colWidths[4];
          doc.text(formatCurrency(lineTotal), xPosition, yPosition);
          yPosition += 6;
        });

        // Total row
        yPosition += 5;
        doc.setFont('helvetica', 'bold');
        doc.text('Gesamtsumme der Honorarleistungen:', pageWidth - 50, yPosition);
        doc.text(formatCurrency(invoice.fld_invoice_total || 0), pageWidth - 20, yPosition);
        yPosition += 10;

        // Tax note
        doc.setFontSize(8);
        doc.setFont('helvetica', 'italic');
        doc.text('Die erbrachten Bildungsleistungen sind gemäß § 4 Nr. 21 UStG von der Umsatzsteuer befreit.', 20, yPosition);
        yPosition += 15;

        // Payment information
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Ich bitte Sie, die Gesamtsumme innerhalb der vereinbarten Frist gemäß dem Honorarvertrag zu begleichen.', 20, yPosition);
        yPosition += 8;
        doc.text(`IBAN: ${teacher.fld_bank_act || 'N/A'}`, 20, yPosition);
        yPosition += 15;

        // Footer
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Mit Freundlichen Grüßen', 20, yPosition);
        yPosition += 5;
        doc.text(`${teacher.fld_first_name} ${teacher.fld_last_name}`, 20, yPosition);
        yPosition += 10;

        doc.setFontSize(8);
        doc.text('Diese Abrechnung wurde mittels EDV erstellt und ist auch ohne Unterschrift gültig.', pageWidth / 2, yPosition, { align: 'center' });

        // Save PDF
        const fileName = `TeacherInvoice_${teacher.fld_last_name}_${teacher.fld_first_name}_${invoice.fld_id}.pdf`;
        doc.save(fileName);
        
        toast.success('PDF downloaded successfully');
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Failed to generate PDF');
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading invoice...</div>
        </div>
      </div>
    );
  }

  if (!invoiceData) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-gray-500">Invoice not found</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <Link to={type === 'receivables' ? '/financials/receivables' : '/financials/payables'}>
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to {type === 'receivables' ? 'Receivables' : 'Payables'}
            </Button>
          </Link>
          <Button onClick={handleDownloadPDF}>
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      <div ref={invoiceRef} className="bg-white p-8 rounded-lg shadow-sm">
        {type === 'receivables' && studentInvoiceData && (
          <div className="text-center">
            <img 
              src="/clevercoach-logo.png" 
              alt="CleverCoach Logo" 
              className="h-28 w-auto mx-auto mb-4 ml-4"
            />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Rechnung</h1>
            <p className="text-gray-600">Student Invoice #{studentInvoiceData.invoice.fld_id}</p>
            <p className="text-gray-600">Student: {studentInvoiceData.invoice.tbl_students?.fld_first_name} {studentInvoiceData.invoice.tbl_students?.fld_last_name}</p>
            <p className="text-gray-600">Total: {formatCurrency(studentInvoiceData.invoice.fld_invoice_total || 0)}</p>
          </div>
        )}

        {type === 'payables' && teacherInvoiceData && (
          <div className="text-center">
            <img 
              src="/clevercoach-logo.png" 
              alt="CleverCoach Logo" 
              className="h-28 w-auto mx-auto mb-4 ml-4"
            />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Honorarabrechnung - Selbstgutschrift</h1>
            <p className="text-gray-600">Teacher Invoice #{teacherInvoiceData.invoice.fld_id}</p>
            <p className="text-gray-600">Teacher: {teacherInvoiceData.invoice.tbl_teachers?.fld_first_name} {teacherInvoiceData.invoice.tbl_teachers?.fld_last_name}</p>
            <p className="text-gray-600">Total: {formatCurrency(teacherInvoiceData.invoice.fld_invoice_total || 0)}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceDownload;
